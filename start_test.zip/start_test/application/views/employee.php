<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

<form id="form-basic">
  <label for="fname">Employee name:</label><br>
  <input type="text" id="fname" name="emp_name" value=""><br>
  <label for="Salary">Salary :</label><br>
  <input type="text" id="lname" name="salary" value=""><br><br>
  <label for="department">Department :</label><br>
  <select name="department">
    <?php foreach($dept as $row_dept){ ?>
      <option value="<?php echo $row_dept->dept_id?>"><?php echo $row_dept->dept_name?></option>
    <?php } ?>
  </select>
  <br><br>
   <label for="department">Hobbies :</label><br>
  <select name="hobbies">
      <option value="reading">Reading</option>
      <option value="riding">Riding</option>
      <option value="writing">Writing</option>
  </select>
  <br><br>
   <label for="Gender">Gender :</label><br>
   <label for="Male">Male</label>
      <input type="radio"  name="gender" value="male"><br>

   <label for="Female">Female</label>
   <input type="radio"  name="gender" value="female"><br>
  <button type="button" id="save">Save</button>
</form> 
</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"> </script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"> </script>  
<script type="text/javascript">
  $("#form-basic").validate({
    rules:{
      emp_name:{
        required:true,
      },
      department:{
        required:true,
      }
    },
    messages:{
    emp_name:{
      required:"Please Enter Employee Name",
    },
    department:{
      required:"Please Enter Departmnent",
    },
  }
  })
  $("#save").on('click',function(){
  
    var formData = $("#form-basic").serializeArray();
    var dataJson = {'basic':formData};
    
    dataJson = JSON.stringify(dataJson);
     $.ajax({
       url : "add_data",
       type :"post",
       data:{"data_json":dataJson},
       success:function(res){
         alert(res);
       }
     });
  });
   

</script>
