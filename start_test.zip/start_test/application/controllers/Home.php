<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
 	public function __construct(){
 		parent::__construct();
 		$this->load->model('home_model');
 	}

	public function index()
	{
		$input['dept']= $this->home_model->get_department();
		$this->load->view('employee',$input);
	}

	public function add_data(){
		$data= $this->input->post("data_json",true);
		print_r($data);die;
	}
}
