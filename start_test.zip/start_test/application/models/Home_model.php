<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {

	public function get_department(){
		$dept_data = $this->db->get('dept_table')->result();
		return $dept_data;
	}
	 public function add_data(){
	 	
	 }

}
?>